<?php $__env->startSection('contenido'); ?>
<ol class="breadcrumb">
    <li class="breadcrumb-item active">Galeria</li>
    
</ol>
<div class="container-fluid">
    <div id="ui-view">
        <div>
            <div class="animated fadeIn">
                <div class="row">
                    
                    <?php if(Session::has('succes')): ?>
                        <div class="col-lg-8">
                            <div class="alert alert-success alert-dismissible fade show mb-4 mt-4" role="alert">
                                <?php echo e(Session::get('succes')); ?>

                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                        </div>
                    <?php endif; ?>
                    
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-header">
                                <h5>MI GALERIA</h5>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-lg-12 form-group">
                                        <a href="<?php echo e(route('create.equipo')); ?>" type="button" class="btn btn-success" data-toggle="modal" data-target="#addphoto">Agregar foto</a>

                                        <!-- Modal -->
                                        <div class="modal fade" id="addphoto" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                                            <form action="<?php echo e(route('store.galeria')); ?>" method="POST" role="form"  enctype="multipart/form-data">
                                                <?php echo e(csrf_field()); ?>

                                                <div class="modal-dialog modal-dialog-centered" role="document">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                        <h5 class="modal-title" id="exampleModalCenterTitle">Subir foto</h5>
                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                            <span aria-hidden="true">&times;</span>
                                                        </button>
                                                        </div>
                                                        <div class="modal-body">
                                                            <div class="row">
                                                                <div class="col-lg-12">
                                                                    <input type="file" name="imagen" class="form-control <?php echo e($errors->has('imagen') ? ' is-invalid' : ''); ?>">
                                                                    <?php if($errors->has('imagen')): ?>
                                                                        <span class="invalid-feedback" role="alert">
                                                                            <strong><?php echo e($errors->first('imagen')); ?></strong>
                                                                        </span>
                                                                    <?php endif; ?>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
                                                        <button type="submit" class="btn btn-primary">Guardar</button>
                                                        </div>
                                                    </div>
                                                    </div>
                                            </form>
                                        </div>
                                    </div>
                                    <div class="col-lg-12">
                                        <div class="row">
                                            <?php $__currentLoopData = $galeria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="col-lg-3 form-group">
                                                    <div class="card">
                                                        <img src="<?php echo e(asset('galeria/'.$item->imagen)); ?>" style="width:100% !important">
                                                        <div class="card-body">
                                                            <button type="button" class="btn btn-danger btn-sm" data-toggle="modal" data-target="#modal-<?php echo e($item->id); ?>">Eliminar</button>
                                                        </div>
                                                        <?php echo $__env->make('admin.galeria.modal', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                                    </div>
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                        </div>  
                    </div>
                   
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>