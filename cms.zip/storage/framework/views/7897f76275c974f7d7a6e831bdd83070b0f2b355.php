<?php $__env->startSection('1002'); ?>
<section id="about" style="    margin-top: 85px !important;">
    <div class="container">

        <header class="section-header">
            <h3>Nuestro Blog</h3>
            
          </header>
  
          <div class="row about-cols" style="margin-top: 50px !important">
  
            <?php $__currentLoopData = $blog; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4 wow fadeInUp" style="visibility: visible; animation-name: fadeInUp;">
              <a href="http://127.0.0.1:8000/inmaculada/contenido/pagina/blog/<?php echo e($item->slug); ?>">
                <div class="about-col">
                    <div class="img">
                      <img src="<?php echo e(asset('blog/'.$item->imagen)); ?>" alt="" class="img-fluid" style="width: 100% !important">
                      <div class="icon"><i class="ion-ios-speedometer-outline"></i></div>
                    </div>
                    <h2 class="title"><a href="#"><?php echo e($item->titulo); ?></a></h2>
                    <p>
                      <?php echo e($item->excerpt); ?>

                    </p>
                  </div>
              </a>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  
            
          </div>

          <div class="row">
            <div class="col-lg-12">
                <?php echo e($galeria->render()); ?>

            </div>
          </div>

    </div>
  </section>
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('plantillas.1002.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>