<?php $__env->startSection('contenido'); ?>
<ol class="breadcrumb">
    <li class="breadcrumb-item active">Listado de paginas</li>
    
</ol>
<div class="container-fluid">
    <div id="ui-view">
        <div>
            <div class="animated fadeIn">
                <div class="row">
                    <div class="col-lg-8">
                    <?php if(Session::has('succes')): ?>
                        <div class="alert alert-success alert-dismissible fade show mb-4 mt-4" role="alert">
                            <?php echo e(Session::get('succes')); ?>

                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                    <?php endif; ?>
                    <div class="card">
                        <div class="card-header">
                            <h4>LISTADO DE PAGINAS</h4>
                        </div>
                        <div class="card-body">
                                <div class="row">
                                 
                                    <div class="col-lg-12">
                                        <table class="table table-sm">
                                            <thead class="thead-dark">
                                                <th>Dominio</th>
                                                <th>Usuario</th>
                                                <th>Correo</th>
                                                <th>Estado</th>
                                                <th>Opciones</th>
                                            </thead>
                                            <?php $__currentLoopData = $paginas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tbody>
                                                <td><a href="http://127.0.0.1:8000/<?php echo e($item->dominio); ?>" target="_blank"><?php echo e($item->dominio); ?></a></td>
                                                <td><?php echo e($item->name); ?></td>
                                                <td><?php echo e($item->email); ?></td>
                                                <td>
                                                    <?php if($item->estado == 'activo'): ?>
                                                        <span class="badge badge-success">Activo</span>
                                                    <?php else: ?>
                                                        <span class="badge badge-danger">Desactivo</span>
                                                    <?php endif; ?>
                                                </td>
                                                <th>
                                                    <div class="dropdown">
                                                        <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                          Opciones
                                                        </button>
                                                        <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                                            <?php if($item->estado != 'activo'): ?>
                                                                <a class="dropdown-item" data-toggle="modal" data-target="#dominio-<?php echo e($item->id); ?>">Activar</a>
                                                            <?php else: ?>
                                                                <a class="dropdown-item" data-toggle="modal" data-target="#modal-activar-<?php echo e($item->id); ?>">Desactivar</a>
                                                            <?php endif; ?>

                                                          
                                                        </div>
                                                      </div>
                                                      <!-- Modal -->
                                                      <?php echo $__env->make('panel.paginas.desactivar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                                </th>
                                            </tbody>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </table>
                                    </div>
                                </div>
                        </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>