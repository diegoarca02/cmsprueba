 
 <?php $__env->startSection('1002'); ?>
 <!--==========================
    Intro Section
  ============================-->
  <section id="intro" >
    <div class="intro-container">
      <div id="introCarousel" class="carousel  slide carousel-fade" data-ride="carousel">

        <ol class="carousel-indicators"></ol>

        <div class="carousel-inner" role="listbox">

          <div class="carousel-item active">
            <div class="carousel-background"><img src="<?php echo e(asset('sliders/'.$slider[0]->imagen)); ?>" alt=""></div>
            <div class="carousel-container">
              <div class="carousel-content">
                <h2><?php echo e($slider[0]->titulo); ?></h2>
                
              </div>
            </div>
          </div>

          <?php $__currentLoopData = $slider; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($item->id != $slider[0]->id): ?>
            <div class="carousel-item">
              <div class="carousel-background"><img src="<?php echo e(asset('sliders/'.$item->imagen)); ?>" alt=""></div>
              <div class="carousel-container">
                <div class="carousel-content">
                  <h2><?php echo e($item->titulo); ?></h2>
                </div>
              </div>
            </div>
          <?php endif; ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

          

        </div>

        <a class="carousel-control-prev" href="#introCarousel" role="button" data-slide="prev">
          <span class="carousel-control-prev-icon ion-chevron-left" aria-hidden="true"></span>
          <span class="sr-only">Previous</span>
        </a>

        <a class="carousel-control-next" href="#introCarousel" role="button" data-slide="next">
          <span class="carousel-control-next-icon ion-chevron-right" aria-hidden="true"></span>
          <span class="sr-only">Next</span>
        </a>

      </div>
    </div>
  </section><!-- #intro -->

  <main id="main">

    <!--==========================
      Featured Services Section
    ============================-->
    

    <!--==========================
      About Us Section
    ============================-->
    <section id="about">
      <div class="container">

        <header class="section-header mb-4">
          <h3><?php echo e($seccion_uno->titulo); ?></h3>
          
        </header>

        <div class="row about-cols mt-4" style="margin-top:50px !important">

          <div class="col-md-6 wow fadeInUp">
              <img src="<?php echo e(asset('secciones/'.$seccion_uno->imagen)); ?>" style="width:100%">
          </div>

          <div class="col-md-6 wow fadeInUp" data-wow-delay="0.1s" style="word-wrap: break-word;">
            <p><?php echo $seccion_uno->descripcion?></p>
          </div>


        </div>

      </div>
    </section><!-- #about -->

    <!--==========================
      Services Section
    ============================-->

    <section id="about">
      <div class="container">

        <header class="section-header">
          <h3>Nuestro Blog</h3>
          
        </header>

        <div class="row about-cols" style="margin-top: 50px !important">

          <?php $__currentLoopData = $blog_index; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="col-md-4 wow fadeInUp" style="visibility: visible; animation-name: fadeInUp;">
            <div class="about-col">
              <div class="img">
                <img src="<?php echo e(asset('blog/'.$item->imagen)); ?>" alt="" class="img-fluid" style="width: 100% !important">
                <div class="icon"><i class="ion-ios-speedometer-outline"></i></div>
              </div>
              <h2 class="title"><a href="http://127.0.0.1:8000/inmaculada/contenido/pagina/blog/<?php echo e($item->slug); ?>"><?php echo e($item->titulo); ?></a></h2>
              <p>
                <?php echo e($item->excerpt); ?>

              </p>
            </div>
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

          
        </div>

      </div>
    </section>



      <!--==========================
      About Us Section
    ============================-->
    <section id="about">
      <div class="container">

        <header class="section-header mb-4">
          <h3><?php echo e($seccion_dos->titulo); ?></h3>
          
        </header>

        <div class="row about-cols mt-4" style="margin-top:50px !important">

          <div class="col-md-6 wow fadeInUp" data-wow-delay="0.1s" style="word-wrap: break-word;">
            <p><?php echo $seccion_dos->descripcion?></p>
          </div>
          
          <div class="col-md-6 wow fadeInUp">
              <img src="<?php echo e(asset('secciones/'.$seccion_dos->imagen)); ?>" style="width:100%">
          </div>

          


        </div>

      </div>
    </section><!-- #about -->



    <!--==========================
      Portfolio Section
    ============================-->
    <section id="portfolio"  class="section-bg" >
      <div class="container">

        <header class="section-header">
          <h3 class="section-title">Galería</h3>
        </header>


        <div class="row portfolio-container">

          <?php $__currentLoopData = $galeria_index; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-4 col-md-6 portfolio-item filter-app wow fadeInUp">
            <div class="portfolio-wrap">
              <figure>
                <img src="<?php echo e(asset('galeria/'.$item->imagen)); ?>" class="img-fluid" alt="">
                <a href="<?php echo e(asset('galeria/'.$item->imagen)); ?>" data-lightbox="portfolio" data-title="App 1" class="link-preview" title="Preview"><i class="ion ion-eye"></i></a>
                <a href="#" class="link-details" title="More Details"><i class="ion ion-android-open"></i></a>
              </figure>
            </div>
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

          

        </div>

      </div>
    </section><!-- #portfolio -->

    <!--==========================
      Clients Section
    ============================-->
    <section id="clients" class="wow fadeInUp">
      <div class="container">

        <header class="section-header">
          <h3>Enlaces Recomendados</h3>
        </header>

        <div class="owl-carousel clients-carousel">
          <?php $__currentLoopData = $enlace; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e($item->enlace); ?>" target="_blank">
              <img src="<?php echo e(asset('enlace/'.$item->imagen)); ?>" alt="">
            </a>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          
        </div>

      </div>
    </section><!-- #clients -->

    <!--==========================
      Clients Section
    ============================-->
    <section id="testimonials" class="section-bg wow fadeInUp">
      <div class="container">

        <header class="section-header">
          <h3>Nuestro Equipo</h3>
        </header>

        <div class="owl-carousel testimonials-carousel">

          <?php $__currentLoopData = $equipo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="testimonial-item">
            <img src="<?php echo e(asset('equipo/'.$item->imagen)); ?>" class="testimonial-img" alt="">
            <h3><?php echo e($item->nombres); ?></h3>
            <h4><?php echo e($item->cargo); ?></h4>
           
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

         

        </div>

      </div>
    </section><!-- #testimonials -->

    <!--==========================
      Team Section
    ============================-->
    



  </main>
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('plantillas.1002.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>