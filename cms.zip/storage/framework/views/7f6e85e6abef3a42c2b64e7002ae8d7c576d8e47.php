<?php $__env->startSection('contenido'); ?>
    <div class="row">
        <div class="col-lg-10">

            <?php if(Session::has('succes')): ?>
                <div class="row">
                    <div class="col-lg-12">
                        <div class="alert alert-success alert-dismissible fade show mb-4" role="alert">
                            <?php echo e(Session::get('succes')); ?>

                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div> 
                    </div>
                </div>
            <?php endif; ?> 

            <div class="card">
                <div class="card-header">
                    <h5>Crear Página</h5>
                </div>
                <div class="card-body">
                    <div class="row">
                        
                        <div class="col-lg-12 form-group">
                            <button class="btn btn-primary" data-toggle="modal" data-target="#openModal">Registrar Página</button>
                        </div>

                        <!-- Modal -->
                        <div class="modal fade" id="openModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                        <form method="POST" action="<?php echo e(route('store.pagina')); ?>" role="form">
                            <?php echo e(csrf_field()); ?>

                            <div class="modal-dialog modal-dialog-centered" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="exampleModalCenterTitle">Registrar Pagina</h5>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                    <div class="modal-body">
                                        <div class="row">
                                            <div class="col-lg-12">
                                                <input type="text" class="form-control <?php echo e($errors->has('dominio') ? ' is-invalid' : ''); ?>" name="dominio" placeholder="Ingrese el dominio de la pagina" name="dominio">
                                                <?php if($errors->has('dominio')): ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong><?php echo e($errors->first('dominio')); ?></strong>
                                                    </span>
                                                <?php endif; ?>
                                            </div>
                                          
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
                                        <button type="submit" class="btn btn-primary">Guardar</button>
                                    </div>
                                </div>
                            </div>
                        </form>
                        </div>
                    </div>
                </div>
                <div class="card-footer">

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>