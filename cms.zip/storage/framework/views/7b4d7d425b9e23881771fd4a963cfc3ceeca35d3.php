<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title>Login CMS</title>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

    <link href="<?php echo e(asset('css/coreui-icons.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/flag-icon.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/font-awesome.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/simple-line-icons.css')); ?>" rel="stylesheet">

    <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/pace.min.css')); ?>" rel="stylesheet">
</head>
<body clas="app flex-row align-items-center">
   
        

      
    <?php echo $__env->yieldContent('content'); ?>
     

    <script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/pace.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/perfect-scrollbar.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/coreui.min.js')); ?>"></script>
</body>
</html>
