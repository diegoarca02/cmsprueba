<?php $__env->startSection('contenido'); ?>
<ol class="breadcrumb">
    <li class="breadcrumb-item active">Bandeja de entrada</li>
    
</ol>
<div class="container-fluid">
    <div id="ui-view">
        <div>
            <div class="animated fadeIn">
                <div class="row">
                    
                    <?php if(Session::has('succes')): ?>
                        <div class="col-lg-8">
                            <div class="alert alert-success alert-dismissible fade show mb-4 mt-4" role="alert">
                                <?php echo e(Session::get('succes')); ?>

                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                        </div>
                    <?php endif; ?>
                    
                    <div class="col-lg-8">
                        <div class="card">
                            <div class="card-header">
                                <h5>LISTADO DE MENSAJES</h5>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    
                                    <div class="col-lg-12">
                                        <table class="table table-sm">
                                            <thead class="thead-dark">
                                                <th>Nombres</th>
                                                <th>Correo</th>
                                                <th>Ver mensaje</th>
                                            </thead>
                                           <?php $__currentLoopData = $mensaje; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tbody>
                                                    <td><?php echo e($item->nombres); ?></td>
                                                    <td><?php echo e($item->correo); ?></td>
                                                    <td>
                                                        <button class="btn btn-warning" data-toggle="modal" data-target="#open-<?php echo e($item->id); ?>"><i class="fas fa-eye"></i></button>
                                                    </td>

                                                    <!-- Modal -->
                                                    <div class="modal fade" id="open-<?php echo e($item->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                                                        <div class="modal-dialog modal-dialog-centered" role="document" style="max-width:750px !important">
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                            <h5 class="modal-title" id="exampleModalCenterTitle"><?php echo e($item->nombres); ?></h5>
                                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                <span aria-hidden="true">&times;</span>
                                                            </button>
                                                            </div>
                                                            <div class="modal-body">
                                                                <div class="row">
                                                                    <div class="col-lg-6">
                                                                        <input type="text" class="form-control" readonly value="<?php echo e($item->correo); ?>">
                                                                    </div>
                                                                    <div class="col-lg-6">
                                                                        <input type="text" class="form-control" readonly value="<?php echo e($item->telefono); ?>">
                                                                    </div>
                                                                    <div class="col-lg-12">
                                                                        <hr>
                                                                        <?php echo $item->mensaje?>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="modal-footer">
                                                            <button type="button" class="btn btn-danger" data-dismiss="modal">Cerrar</button>
                                                           
                                                        </div>
                                                        </div>
                                                    </div>
                                                </tbody>
                                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </table>
                                    </div>
                                </div>
                            </div>
                            
                        </div>  
                    </div>
                   
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>