<?php $__env->startSection('1003'); ?>
<section class="section section-xl bg-default">
    <div class="container">
      <h2>Galeria</h2>
      <hr class="divider bg-madison">
      <div class="offset-top-60">
        <div class="row row-30 justify-content-sm-center" data-lightgallery="group">
          <?php $__currentLoopData = $galeria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="col-sm-10 col-md-6 col-lg-4">
            <figure class="thumbnail-classic">
              <div class="thumbnail-classic-img-wrap"><img src="<?php echo e(asset('galeria/'.$item->imagen)); ?>" alt="" width="370" height="370"/>
              </div>
              <figcaption class="thumbnail-classic-caption text-center">
                <div>
                  <h4 class="thumbnail-classic-title">ZOOM</h4>
                </div>
                <hr class="divider divider-sm"/>
                
              </figcaption>
            </figure>
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          
        </div>

        <div class="row">
            <div class="col-lg-12">
                <?php echo e($galeria->render()); ?>

            </div>
          </div>
      </div>
    </div>
  </section>
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('plantillas.1003.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>