<?php $__env->startSection('contenido'); ?>
<ol class="breadcrumb">
    <li class="breadcrumb-item active">Patterns</li>
    
</ol>
<div class="container-fluid">
    <div id="ui-view">
        <div>
            <div class="animated fadeIn">
                <div class="row">
                    
                    <?php if(Session::has('succes')): ?>
                        <div class="col-lg-8">
                            <div class="alert alert-success alert-dismissible fade show mb-4 mt-4" role="alert">
                                <?php echo e(Session::get('succes')); ?>

                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                        </div>
                    <?php endif; ?>
                    
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-header">
                                <h5>MI GALERIA</h5>
                            </div>
                            <div class="card-body">
                                <div class="row">

                                    <div class="col-lg-2">
                                        <form action="<?php echo e(route('patterns.update',$idgeneral)); ?>" method="POST">
                                            <?php echo e(csrf_field()); ?>

                                            <input name="_method" type="hidden" value="PATCH">
                                            <div class="card">
                                                <input type="hidden" name="fondo" value="<?php echo e($general->fondo); ?>">
                                                
                                                <img src="<?php echo e(asset('patterns/'.$general->fondo)); ?>" style="width: 100%">
                                                <div class="card-body" style="background: #191919 !important; color: white !important">
                                                    <center><button class="btn btn-success btn-sm" type="submit">Seleccionar</button></center>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                    
                                    <div class="col-lg-2">
                                        <form action="<?php echo e(route('patterns.update',$idgeneral)); ?>" method="POST">
                                            <?php echo e(csrf_field()); ?>

                                            <input name="_method" type="hidden" value="PATCH">
                                            <div class="card">
                                                <input type="hidden" name="fondo" value="fondo1.png">
                                                
                                                <img src="<?php echo e(asset('patterns/fondo1.png')); ?>" style="width: 100%">
                                                <div class="card-body">
                                                    <center><button class="btn btn-success btn-sm" type="submit">Seleccionar</button></center>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                   
                                    <div class="col-lg-2">
                                        <form action="<?php echo e(route('patterns.update',$idgeneral)); ?>" method="POST">
                                            <?php echo e(csrf_field()); ?>

                                            <input name="_method" type="hidden" value="PATCH">
                                            <div class="card">
                                                <input type="hidden" name="fondo" value="fondo1.png">
                                                
                                                <img src="<?php echo e(asset('patterns/fondo1.png')); ?>" style="width: 100%">
                                                <div class="card-body">
                                                    <center><button class="btn btn-success btn-sm" type="submit">Seleccionar</button></center>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                    <div class="col-lg-2">
                                        <form action="<?php echo e(route('patterns.update',$idgeneral)); ?>" method="POST">
                                            <?php echo e(csrf_field()); ?>

                                            <input name="_method" type="hidden" value="PATCH">
                                            <div class="card">
                                                <input type="hidden" name="fondo" value="fondo2.png">
                                                <img src="<?php echo e(asset('patterns/fondo2.png')); ?>" style="width: 100%">
                                                <div class="card-body">
                                                    <center><button class="btn btn-success btn-sm" type="submit">Seleccionar</button></center>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                    <div class="col-lg-2">
                                        <form action="<?php echo e(route('patterns.update',$idgeneral)); ?>" method="POST">
                                            <?php echo e(csrf_field()); ?>

                                            <input name="_method" type="hidden" value="PATCH">
                                            <div class="card">
                                                <input type="hidden" name="fondo" value="fondo3.png">
                                                <img src="<?php echo e(asset('patterns/fondo3.png')); ?>" style="width: 100%">
                                                <div class="card-body">
                                                    <center><button class="btn btn-success btn-sm" type="submit">Seleccionar</button></center>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                    <div class="col-lg-2">
                                        <form action="<?php echo e(route('patterns.update',$idgeneral)); ?>" method="POST">
                                            <?php echo e(csrf_field()); ?>

                                            <input name="_method" type="hidden" value="PATCH">
                                            <div class="card">
                                                <input type="hidden" name="fondo" value="fondo4.png">
                                                <img src="<?php echo e(asset('patterns/fondo4.png')); ?>" style="width: 100%">
                                                <div class="card-body">
                                                    <center><button class="btn btn-success btn-sm" type="submit">Seleccionar</button></center>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                    <div class="col-lg-2">
                                        <form action="<?php echo e(route('patterns.update',$idgeneral)); ?>" method="POST">
                                            <?php echo e(csrf_field()); ?>

                                            <input name="_method" type="hidden" value="PATCH">
                                            <div class="card">
                                                <input type="hidden" name="fondo" value="fondo5.png">
                                                <img src="<?php echo e(asset('patterns/fondo5.png')); ?>" style="width: 100%">
                                                <div class="card-body">
                                                    <center><button class="btn btn-success btn-sm" type="submit">Seleccionar</button></center>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                    <div class="col-lg-2">
                                        <form action="<?php echo e(route('patterns.update',$idgeneral)); ?>" method="POST">
                                            <?php echo e(csrf_field()); ?>

                                            <input name="_method" type="hidden" value="PATCH">
                                            <div class="card">
                                                <input type="hidden" name="fondo" value="fondo6.png">
                                                <img src="<?php echo e(asset('patterns/fondo6.png')); ?>" style="width: 100%">
                                                <div class="card-body">
                                                    <center><button class="btn btn-success btn-sm" type="submit">Seleccionar</button></center>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                    <div class="col-lg-2">
                                        <form action="<?php echo e(route('patterns.update',$idgeneral)); ?>" method="POST">
                                            <?php echo e(csrf_field()); ?>

                                            <input name="_method" type="hidden" value="PATCH">
                                            <div class="card">
                                                <input type="hidden" name="fondo" value="fondo7.png">
                                                <img src="<?php echo e(asset('patterns/fondo7.png')); ?>" style="width: 100%">
                                                <div class="card-body">
                                                    <center><button class="btn btn-success btn-sm" type="submit">Seleccionar</button></center>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                    <div class="col-lg-2">
                                        <form action="<?php echo e(route('patterns.update',$idgeneral)); ?>" method="POST">
                                            <?php echo e(csrf_field()); ?>

                                            <input name="_method" type="hidden" value="PATCH">
                                            <div class="card">
                                                <input type="hidden" name="fondo" value="fondo8.png">
                                                <img src="<?php echo e(asset('patterns/fondo8.png')); ?>" style="width: 100%">
                                                <div class="card-body">
                                                    <center><button class="btn btn-success btn-sm" type="submit">Seleccionar</button></center>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                    <div class="col-lg-2">
                                        <form action="<?php echo e(route('patterns.update',$idgeneral)); ?>" method="POST">
                                            <?php echo e(csrf_field()); ?>

                                            <input name="_method" type="hidden" value="PATCH">
                                            <div class="card">
                                                <input type="hidden" name="fondo" value="fondo9.png">
                                                <img src="<?php echo e(asset('patterns/fondo9.png')); ?>" style="width: 100%">
                                                <div class="card-body">
                                                    <center><button class="btn btn-success btn-sm" type="submit">Seleccionar</button></center>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                    <div class="col-lg-2">
                                        <form action="<?php echo e(route('patterns.update',$idgeneral)); ?>" method="POST">
                                            <?php echo e(csrf_field()); ?>

                                            <input name="_method" type="hidden" value="PATCH">
                                            <div class="card">
                                                <input type="hidden" name="fondo" value="fondo10.png">
                                                <img src="<?php echo e(asset('patterns/fondo10.png')); ?>" style="width: 100%">
                                                <div class="card-body">
                                                    <center><button class="btn btn-success btn-sm" type="submit">Seleccionar</button></center>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                   
                                </div>
                            </div>
                            
                        </div>  
                    </div>
                   
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>