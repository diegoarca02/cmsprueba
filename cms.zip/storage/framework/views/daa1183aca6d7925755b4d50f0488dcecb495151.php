<?php $__env->startSection('contenido'); ?>

<div class="row">
    <div class="col-lg-4">
        <form method="POST" action="<?php echo e(route('store.config_menu')); ?>" role="form">
            <?php echo e(csrf_field()); ?>

            <div class="card">
                <div class="card-header">
                    <h5>CONFIGURACION DEL MENÚ</h5>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-lg-12 form-group">
                            <input type="text" class="form-control" placeholder="Titulo de la web" name="titulo">
                        </div>
                        <div class="col-lg-12 form-group">
                            <label>Color de texto</label>
                            <input class="jscolor form-control" name="color">
                        </div>
                        <div class="col-lg-12 form-group">
                            <label>Color de fondo</label>
                            <input class="jscolor form-control" name="background">
                        </div>
                    </div>
                </div>
                <div class="card-footer">
                    <button class="btn btn-primary" type="submit">Guardar</button>
                </div>
            </div>
        </form>
    </div>
</div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>