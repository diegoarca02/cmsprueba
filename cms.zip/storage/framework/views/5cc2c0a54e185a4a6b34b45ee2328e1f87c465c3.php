<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title><?php echo e($general->titulo); ?></title>
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <meta content="" name="keywords">
  <meta content="" name="description">
  <link rel="icon" type="image/ico" href="<?php echo e(asset('general/'.$general->favicon)); ?>" sizes="any">
  <!-- Favicons -->

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,700,700i|Montserrat:300,400,500,700" rel="stylesheet">

  <!-- Bootstrap CSS File -->
  <link href="<?php echo e(asset('themes/1002/lib/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">

  <!-- Libraries CSS Files -->
  <link href="<?php echo e(asset('themes/1002/lib/font-awesome/css/font-awesome.min.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('themes/1002/lib/animate/animate.min.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('themes/1002/lib/ionicons/css/ionicons.min.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('themes/1002/lib/owlcarousel/assets/owl.carousel.min.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('themes/1002/lib/lightbox/css/lightbox.min.css')); ?>" rel="stylesheet">

  <!-- Main Stylesheet File -->
  <link href="<?php echo e(asset('themes/1002/css/style.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('css/all.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('css/fuentes.css')); ?>" rel="stylesheet">

  <!-- =======================================================
    Theme Name: BizPage
    Theme URL: https://bootstrapmade.com/bizpage-bootstrap-business-template/
    Author: BootstrapMade.com
    License: https://bootstrapmade.com/license/
  ======================================================= -->
</head>

<body style="font-family: <?php echo e($general->fuente); ?> !important; font-size: <?php echo e($general->size); ?> !important; background-image: url(<?php echo e(asset('recursos_fondo/'.$general->fondo)); ?>) !important">

  <!--==========================
    Header
  ============================-->
  <header id="header" style="background: <?php echo e($menu->background); ?> !important">
    <div class="container-fluid">

      <div id="logo" class="pull-left">
        
        <h1><a href="" class="scrollto" style="color: <?php echo e($menu->color); ?> !important"><img src="<?php echo e(asset('general/'.$general->logo)); ?>" style="width:40px" > <?php echo e($menu->titulo); ?></a></h1>
        <!-- Uncomment below if you prefer to use an image logo -->
        <!-- <a href="#intro"><img src="img/logo.png" alt="" title="" /></a>-->
      </div>

      <nav id="nav-menu-container">
        <ul class="nav-menu">
        
          <?php $__currentLoopData = $items_menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="menu-active"><a style="color: <?php echo e($menu->color); ?> !important" href="<?php echo e($item->enlace); ?>"><?php echo $item->icono?> <?php echo e($item->titulo); ?></a>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
      </nav><!-- #nav-menu-container -->
    </div>
  </header><!-- #header -->

 <?php echo $__env->yieldContent('1002'); ?>

  <!--==========================
    Footer
  ============================-->
  <footer id="footer" >
    <div class="footer-top" style="background: <?php echo e($footer->background); ?> !important">
      <div class="container">
        <div class="row">

          <div class="col-lg-3 col-md-6 footer-info">
            <img src="<?php echo e(asset('general/'.$general->logo)); ?>" style="width:120px !important">
          </div>

          <div class="col-lg-3 col-md-6 footer-links">
            <h4>Enlaces rapidos</h4>
            <ul>
          
              <?php $__currentLoopData = $items_menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li style="color: <?php echo e($menu->color); ?> !important"><a href="<?php echo e($item->enlace); ?>"><?php echo e($item->titulo); ?></a>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
          </div>

          <div class="col-lg-3 col-md-6 footer-contact">
            <h4>Contactanos</h4>
            <p>
             <?php echo $footer->direccion?><br>
              <strong>Telefono:</strong> <?php echo e($footer->telefono); ?><br>
              <strong>Email:</strong> <?php echo e($footer->correo); ?><br>
            </p>

          
          </div>

          <div class="col-lg-3 col-md-6 footer-newsletter">
            <h3><?php echo e($menu->titulo); ?></h3>
            
            
          </div>

        </div>
      </div>
    </div>

    <div class="container">
      <div class="copyright">
        <p><?php echo e($footer->cr); ?></p>
      </div>
     
    </div>
  </footer><!-- #footer -->

  <a href="#" class="back-to-top"><i class="fa fa-chevron-up"></i></a>
  <!-- Uncomment below i you want to use a preloader -->
  <!-- <div id="preloader"></div> -->

  <!-- JavaScript Libraries -->
  <script src="<?php echo e(asset('themes/1002/lib/jquery/jquery.min.js')); ?>"></script>
  <script src="<?php echo e(asset('themes/1002/lib/jquery/jquery-migrate.min.js')); ?>"></script>
  <script src="<?php echo e(asset('themes/1002/lib/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
  <script src="<?php echo e(asset('themes/1002/lib/easing/easing.min.js')); ?>"></script>
  <script src="<?php echo e(asset('themes/1002/lib/superfish/hoverIntent.js')); ?>"></script>
  <script src="<?php echo e(asset('themes/1002/lib/superfish/superfish.min.js')); ?>"></script>
  <script src="<?php echo e(asset('themes/1002/lib/wow/wow.min.js')); ?>"></script>
  <script src="<?php echo e(asset('themes/1002/lib/waypoints/waypoints.min.js')); ?>"></script>
  <script src="<?php echo e(asset('themes/1002/lib/counterup/counterup.min.js')); ?>"></script>
  <script src="<?php echo e(asset('themes/1002/lib/owlcarousel/owl.carousel.min.js')); ?>"></script>
  <script src="<?php echo e(asset('themes/1002/lib/isotope/isotope.pkgd.min.js')); ?>"></script>
  <script src="<?php echo e(asset('themes/1002/lib/lightbox/js/lightbox.min.js')); ?>"></script>
  <script src="<?php echo e(asset('themes/1002/lib/touchSwipe/jquery.touchSwipe.min.js')); ?>"></script>
  <!-- Contact Form JavaScript File -->
  <script src="<?php echo e(asset('themes/1002/contactform/contactform.js')); ?>"></script>

  <!-- Template Main Javascript File -->
  <script src="<?php echo e(asset('themes/1002/js/main.js')); ?>"></script>
  <script src="<?php echo e(asset('js/all.js')); ?>"></script>
</body>
</html>
