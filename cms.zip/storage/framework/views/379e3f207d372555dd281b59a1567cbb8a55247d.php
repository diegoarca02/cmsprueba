<?php $__env->startSection('1002'); ?>
<section id="about" style="    margin-top: 85px !important;">
    <div class="container">

        <header class="section-header">
            <h3><?php echo e($blog->titulo); ?></h3>
            
          </header>
          <div class="row">
              <div class="col-lg-12">
                  <?php echo $blog->contenido?>
              </div>
          </div>
         

    </div>
  </section>
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('plantillas.1002.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>