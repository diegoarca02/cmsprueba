<?php $__env->startSection('contenido'); ?>
<ol class="breadcrumb">
    <li class="breadcrumb-item active">Mercado de plantillas</li>
    
</ol>
<div class="container-fluid">
    <div id="ui-view">
        <div>
            <div class="animated fadeIn">
                <div class="row">
                    <div class="col-lg-12">
                    <?php if(Session::has('succes')): ?>
                        <div class="alert alert-success alert-dismissible fade show mb-4 mt-4" role="alert">
                            <?php echo e(Session::get('succes')); ?>

                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                    <?php endif; ?>
                        <div class="card">
                            <div class="card-body">
                                <div class="row">
                                    <?php $__currentLoopData = $plantillas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($item->id == $pagina->idplantilla): ?>
                                            <div class="col-lg-4 form-group">
                                                <form method="POST" action="<?php echo e(route('update_theme')); ?>" role="form">
                                                    <?php echo e(csrf_field()); ?>

                                                    <input name="_method" type="hidden" value="PATCH">
                                                <div class="card">
                                                    <div class="card-header" style="background: #353535 !important;
                                                    color: white !important;">
                                                        <input type="hidden" value="<?php echo e($item->id); ?>" name="idplantilla">
                                                        <h5><?php echo e($item->titulo); ?></h5>
                                                        <span>Codigo de plantilla: <?php echo e($item->id); ?></span>
                                                    </div>
                                                    <img src="<?php echo e(asset('portadas/'.$item->portada)); ?>" style="width: 100% !important">
                                                    <div class="card-body">
                                                        <p class="text-justify"><?php echo e(substr($item->descripcion,0,150)); ?></p>
                                                    </div>
                                                    <div class="card-footer">
                                                        <button class="btn btn-primary" type="submit">Activar plantilla</button>
                                                    </div>
                                                </div>
                                                </form>
                                            </div>
                                        <?php elseif($item->id != $pagina->idplantilla): ?>
                                            <div class="col-lg-4 form-group">
                                                <form method="POST" action="<?php echo e(route('update_theme')); ?>" role="form">
                                                    <?php echo e(csrf_field()); ?>

                                                    <input name="_method" type="hidden" value="PATCH">
                                                <div class="card">
                                                    <div class="card-header">
                                                        <input type="hidden" value="<?php echo e($item->id); ?>" name="idplantilla">
                                                        <h5><?php echo e($item->titulo); ?></h5>
                                                        <span>Codigo de plantilla: <?php echo e($item->id); ?></span>
                                                    </div>
                                                    <img src="<?php echo e(asset('portadas/'.$item->portada)); ?>" style="width: 100% !important">
                                                    <div class="card-body">
                                                        <p class="text-justify"><?php echo e(substr($item->descripcion,0,150)); ?></p>
                                                    </div>
                                                    <div class="card-footer">
                                                        <button class="btn btn-primary" type="submit">Activar plantilla</button>
                                                    </div>
                                                </div>
                                                </form>
                                            </div>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>  
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>