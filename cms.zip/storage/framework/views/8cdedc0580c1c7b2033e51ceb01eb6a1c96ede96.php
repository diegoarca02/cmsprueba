<?php $__env->startSection('contenido'); ?>
<ol class="breadcrumb">
    <li class="breadcrumb-item"><a href="<?php echo e(route('index.entrada')); ?>">Listado de entradas</a></li>
    <li class="breadcrumb-item active">Registro de entrada</li>
    
</ol>
<div class="container-fluid">
    <div id="ui-view">
        <div>
            <div class="animated fadeIn">
                <div class="row">
                   
                    <?php if(Session::has('succes')): ?>
                        <div class="col-lg-8">
                            <div class="alert alert-success alert-dismissible fade show mb-4 mt-4" role="alert">
                                <?php echo e(Session::get('succes')); ?>

                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                        </div>
                    <?php endif; ?>
                    
                    <div class="col-lg-10">
                        <form method="POST" action="<?php echo e(route('store.entrada')); ?>" role="form">
                            <?php echo e(csrf_field()); ?>

                            <div class="card">
                                <div class="card-header">
                                    <h5>REGISTRO DE ENTRADA</h5>
                                </div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-lg-12 form-group">
                                            <input type="text" class="form-control <?php echo e($errors->has('titulo') ? ' is-invalid' : ''); ?>" placeholder="Titulo de la entrada" name="titulo">
                                            <?php if($errors->has('titulo')): ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($errors->first('titulo')); ?></strong>
                                                </span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="col-lg-12 form-group">
                                            <textarea name="contenido" class="<?php echo e($errors->has('contenido') ? ' is-invalid' : ''); ?>" id="editor"></textarea>
                                            <?php if($errors->has('contenido')): ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($errors->first('contenido')); ?></strong>
                                                </span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="card-footer">
                                    <button type="submit" class="btn btn-primary">Guardar</button>
                                </div>
                            </div>
                        </form>  
                    </div>
                   
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>